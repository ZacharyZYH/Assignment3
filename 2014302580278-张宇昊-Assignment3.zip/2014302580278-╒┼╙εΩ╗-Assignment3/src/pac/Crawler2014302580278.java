package pac;
import java.io.IOException;
import java.util.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;


public class Crawler2014302580278 implements Runnable{
	public class Teacher2014302580278{
		public Teacher2014302580278(){}
		public String name;
		public String tel;
		public String email;
		public String study;
		public String url;
	}
	public Document menu = null;
	private Database2014302580278 db = null;
	public ArrayList<Teacher2014302580278> teachers = new ArrayList<>();
	public Crawler2014302580278() throws IOException{
		
		db = new Database2014302580278();
		menu=Jsoup.connect("http://cs.whu.edu.cn/plus/list.php?tid=36").get();
		String url = "http://cs.whu.edu.cn/plus/";
	    Elements datas=menu.select("dd.j_name");
	    for(Element data:datas){
	    	if(!data.select("a").text().equals("")){
	    		Teacher2014302580278 t = new Teacher2014302580278();
	    		String Turl= url + data.select("a").attr("href");
	    		t.url= Turl;
	    		//get name
	    		t.name = data.select("a").text();
	    		//get field
	    		t.study = data.select("span.job_research").text();
	    		//to the lists
	    		teachers.add(t);
	    	}
	    }
	    
	}
	 
	
	
    
    public void subPage(int n) throws IOException{
    	Document doc = Jsoup.connect(teachers.get(n).url).get();
    	teachers.get(n).tel = doc.select("ul.about_info").get(0).select("li").get(5).text();
    	teachers.get(n).email = doc.select("ul.about_info").get(0).select("li").get(7).text();
    	//System.out.println(teachers.get(n).email);
    	db.execUpdateSQL("insert into professor_info values('"+teachers.get(n).name+"', '"+teachers.get(n).email +"', '"+ teachers.get(n).tel +"', ' "+ teachers.get(n).study +"')");
    }
    int n = 0;
    public synchronized int getN()
    {
    	return n;
    }
    
	@Override
	public void run() {
		// TODO Auto-generated method stub
		long startTime = System.currentTimeMillis();
		while (n < teachers.size()){
			try {
				getN();
				subPage(n);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			n++;
		}
		System.out.println("���߳�����ʱ�䣺 " + (System.currentTimeMillis() - startTime));
	}
}

