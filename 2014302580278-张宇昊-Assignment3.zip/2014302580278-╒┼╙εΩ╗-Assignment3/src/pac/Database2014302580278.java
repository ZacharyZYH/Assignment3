package pac;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class Database2014302580278 {
	
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/assignment3?useUnicode=true&characterEncoding=utf-8";
	private String ip;
	private String user;
	private String pwd;
	private int port;
	private String dbname;
	private String url;

	public Connection conn = null;
	private Statement stmt;
	
	
	public Database2014302580278() {
		this.url = "jdbc:mysql://localhost:3306/assignment3?user=root&password=123456&useUnicode=true&characterEncoding=UTF8";	 
		Connect();
	}

	
	/**
	 * @return
	 * Open Connection
	 */
	public void Connect(){
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
				try {
					conn = DriverManager.getConnection(url);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					Statement stmt = conn.createStatement();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("����MySQL��������ɹ�");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}
	public void closeConn(){
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("�ر�����ʱ����");
		}
	}
	
	//д�����ݿ�
	public synchronized int execUpdateSQL(String str){
		int result;
		try {
			stmt = conn.createStatement();
			result = stmt.executeUpdate(str);
			return result;
		} catch (SQLException e) {
			System.out.println("�﷨�����δ�������ݿ�����ݿ�������");
			return -1;
		}
	}
}
