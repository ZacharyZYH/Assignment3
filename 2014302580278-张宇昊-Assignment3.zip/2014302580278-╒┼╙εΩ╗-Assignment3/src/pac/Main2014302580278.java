package pac;

import java.io.IOException;

public class Main2014302580278 {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Crawler2014302580278 cra = new Crawler2014302580278();
		for(int i=0;i<=5;i++){
			Thread t = new Thread(cra);
			t.start();
		}
		Crawler2014302580278 single = new Crawler2014302580278();
		for(int i=0;i<=1;i++){
			Thread t = new Thread(single);
			//t.start();
		}
		
	}

}
